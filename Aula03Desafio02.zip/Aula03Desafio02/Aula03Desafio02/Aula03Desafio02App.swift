//
//  Aula03Desafio02App.swift
//  Aula03Desafio02
//
//  Created by Student02 on 11/10/23.
//

import SwiftUI

@main
struct Aula03Desafio02App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
