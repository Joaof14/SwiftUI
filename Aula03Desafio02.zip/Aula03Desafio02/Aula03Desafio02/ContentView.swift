//
//  ContentView.swift
//  Aula03Desafio02
//
//  Created by Student02 on 11/10/23.
//

import SwiftUI

struct ContentView: View {
    @State private var isShowingUser = false
    
    var body: some View {
        NavigationStack {
            VStack{
                NavigationLink(destination: Modo1()) {
                        Text("Modo 1")
                    }
                NavigationLink(destination: Modo2()) {
                        Text("Modo 2")
                    }
                
                NavigationLink(destination: self) {
                        Text("Modo 3").onTapGesture {
                            isShowingUser = true
                        }.sheet(isPresented: $isShowingUser) {
                            Text("Você morreu!")
                                .foregroundColor(Color.red)
                                .bold()
                        }
                    }
                

            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
