//
//  Modo2.swift
//  Aula03Desafio02
//
//  Created by Student02 on 11/10/23.
//

import SwiftUI

struct Modo2: View {
    @State public var nome: String = ""
    
    var body: some View {
        NavigationStack {
            VStack{
                Text("Fim da jornada logo a frente, qual o seu nove cavaleiro?").multilineTextAlignment(.center)
                
                TextField("Nome", text: $nome)
                    .multilineTextAlignment(.center)
                    .background()
                    .cornerRadius(5)
                    .padding()
                NavigationLink(destination: Modo4(nome2: nome)) {
                    Text("Acessar Tela")
                }
            }
        }
    }
}

struct Modo2_Previews: PreviewProvider {
    static var previews: some View {
        Modo2()
    }
}
