//
//  Modo1.swift
//  Aula03Desafio02
//
//  Created by Student02 on 11/10/23.
//

import SwiftUI

struct Modo1: View {
    var body: some View {
        Text("Você morreu!")
            .foregroundColor(Color.red)
            .bold()
    }
}

struct Modo1_Previews: PreviewProvider {
    static var previews: some View {
        Modo1()
    }
}
