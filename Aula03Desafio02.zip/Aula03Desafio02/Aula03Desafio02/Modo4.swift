//
//  Modo4.swift
//  Aula03Desafio02
//
//  Created by Student02 on 11/10/23.
//

import SwiftUI

struct Modo4: View {
    @State public var nome2: String = ""
    
    var body: some View {
        Text("Você chegou ao fim da jornada, re-acenda a chama \(nome2)!")
            .bold()
    }
}

struct Modo4_Previews: PreviewProvider {
    static var previews: some View {
        Modo4()
    }
}
