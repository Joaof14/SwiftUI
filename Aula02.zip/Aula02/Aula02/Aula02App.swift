//
//  Aula02App.swift
//  Aula02
//
//  Created by Student02 on 10/10/23.
//

import SwiftUI

@main
struct Aula02App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
