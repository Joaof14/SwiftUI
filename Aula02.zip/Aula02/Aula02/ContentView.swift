//
//  ContentView.swift
//  Aula02
//
//  Created by Student02 on 10/10/23.
//

import SwiftUI

struct ContentView: View {
    @State private var peso: String = ""
    @State private var altura: String = ""
    @State private var imc: String = ""
    @State private var cor: Color = Color("Baixo")
    
    func Calc(peso: String, altura: String) -> String {
        let alt = Float(altura) ?? 0
        let pes = Float(peso) ?? 0
        let res = pes / (alt * alt)
        
        if res < 18.5 {
            cor = Color("Baixo")
            return "Baixo peso"
        }
        else if res >= 18.5 && res <= 24.99 {
            cor = Color("Normal")
            return "Normal"
        }
        else if res >= 25 && res <= 29.99 {
            cor = Color("Sobrepeso")
            return "Sobrepeso"
        }
        else if res >= 30{
            cor = Color("Obesidade")
            return "Obesidade"
        }
        else if res < 0{
            cor = Color("Baixo")
            return "Valores inválidos"
        }
        else {
           return ""
        }

    }
    var body: some View {
        VStack {
            
            VStack{
                Text("Calculadora de IMC")
                    .font(.title)
                    .padding()
                
                TextField("Peso (kg)", text: $peso)
                    .multilineTextAlignment(.center)
                    .background()
                    .cornerRadius(5)
                    .padding()
                    
                
                TextField("Altura (m)", text: $altura)
                    .multilineTextAlignment(.center)
                    .background()
                    .cornerRadius(5)
                    .padding()
                
                Button("Calcular"){
                    imc = Calc(peso: peso, altura: altura)
                }
                .frame(width: 100.0, height: 50.0)
                .foregroundColor(Color.white)
                .background(Color.blue)
                .cornerRadius(10)
                
                Text("\(imc)")
                    .foregroundColor(Color.white)
                    .bold()
                    .font(.title)
                
                Spacer()
            }
        
            Image("tabela-IMC")
                .resizable()
                .shadow(radius: 15)
                .scaledToFit()
                .padding(.bottom, 30)
            
        }.background(cor)
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
