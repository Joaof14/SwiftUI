//
//  ContentView3.swift
//  Aula01
//
//  Created by Student02 on 09/10/23.
//

import SwiftUI

struct ContentView3: View {
    @State private var username: String = "Fulano"
    
    var body: some View {
        ZStack{
            Image("CapaCaminhao")
                .resizable()
                
                .opacity(0.2)
            
            VStack(alignment: .center){
                Text("Bem vindo, \(username)")
                    .font(.title)
                
                HStack(alignment: .center){
                    TextField("Digite Aqui", text: $username)
                        .multilineTextAlignment(.center)
                }
                
                Spacer()
                
                VStack{
                    Image("Logo")
                        .resizable()
                        .scaledToFit()
                    Image("Caminhao")
                        .resizable()
                        .scaledToFit()
                }.frame(width: 200.0, height: 200.0)
                
                Spacer()
                
                Button("Entrar") {
                    /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Action@*/ /*@END_MENU_TOKEN@*/
                    }
                
            }
        }
    }
}

struct ContentView3_Previews: PreviewProvider {
    static var previews: some View {
        ContentView3()
    }
}
