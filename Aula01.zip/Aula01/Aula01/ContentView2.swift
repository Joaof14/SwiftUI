//
//  ContentView2.swift
//  Aula01
//
//  Created by Student02 on 09/10/23.
//

import SwiftUI

struct ContentView2: View {
    var body: some View {
        VStack{
            Image("CapaCaminhao")
                .resizable()
                .scaledToFit()

            
            ZStack{
                Image("CapaCaminhao")
                    .resizable()
                    .scaledToFit()
                    .clipShape(Circle())
                VStack{
                    Text("Hackatruck")
                        .font(.title)
                        .foregroundColor(Color.blue)
                        .bold()
                        .padding(.bottom)
                    
                    Text("")
                        .padding(35)
                }
                
                
            }
            
            HStack{
                Text("Maker")
                    .bold()
                    .foregroundColor(Color.yellow)
                Text("Space")
                    .bold()
                    .foregroundColor(Color.red)
            }
            .padding(.bottom, 30.0)
            .frame(width: 200.0, height: 140.0)
            .background(Color.black)
            

        }
    }
}

struct ContentView2_Previews: PreviewProvider {
    static var previews: some View {
        ContentView2()
    }
}
