//
//  ContentView.swift
//  Aula01
//
//  Created by Student02 on 09/10/23.
// Centralizar imagem, textos

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(alignment: .center) {
            Image("CapaCaminhao").resizable()
                .scaledToFit()
            Text("Hackatruck")
                .font(.title)
                .bold()
                .foregroundColor(Color.blue)
            HStack{
                Text("Maker").bold()
                    .foregroundColor(Color.yellow)
                Text("Space").bold()
                    .foregroundColor(Color.red)
                
            }
        }
        .padding()
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
