//
//  Aula01App.swift
//  Aula01
//
//  Created by Student02 on 09/10/23.
//

import SwiftUI

@main
struct Aula01App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
