//
//  Search.swift
//  Aula03
//
//  Created by Student02 on 11/10/23.
//

import SwiftUI

struct Search: View {
    var body: some View {
            Text("Hello, Hacktruck!")
            .frame(width: 300.0, height: 300.0)
            .background(Color.blue)
            .shadow(radius: 10)
        
    }
}

struct Search_Previews: PreviewProvider {
    static var previews: some View {
        Search()
    }
}
