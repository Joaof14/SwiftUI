//
//  Photos.swift
//  Aula03
//
//  Created by Student02 on 11/10/23.
//

import SwiftUI

struct Photos: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Photos_Previews: PreviewProvider {
    static var previews: some View {
        Photos()
    }
}
