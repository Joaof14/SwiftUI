//
//  Aula03App.swift
//  Aula03
//
//  Created by Student02 on 11/10/23.
//

import SwiftUI

@main
struct Aula03App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
