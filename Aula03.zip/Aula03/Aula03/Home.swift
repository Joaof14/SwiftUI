//
//  Home.swift
//  Aula03
//
//  Created by Student02 on 11/10/23.
//

import SwiftUI

struct Home: View {
    var body: some View {
        List() {ForEach((1...15), id: \.self) {
            Text("Item \($0)")
            }
        }
    }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
