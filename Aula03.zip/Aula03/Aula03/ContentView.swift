//
//  ContentView.swift
//  Aula03
//
//  Created by Student02 on 11/10/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
            Home()
                .badge(2)
                .tabItem{
                    Label("teste", systemImage: "figure.stand.line.dotted.figure.stand")}
            Search()
                .tabItem{
                    Label("", systemImage: "magnifyingglass")}
            Photos()
                .tabItem{
                    Label("teste", systemImage: "photo")}
            Messages()
                .badge(5)
                .tabItem{
                    Label("teste", systemImage: "")}
            Profile()
                .tabItem{
                    Label("teste", systemImage: "person.circle")}
          
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
