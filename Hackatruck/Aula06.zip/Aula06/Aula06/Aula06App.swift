//
//  Aula06App.swift
//  Aula06
//
//  Created by Student02 on 19/10/23.
//

import SwiftUI

@main
struct Aula06App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
