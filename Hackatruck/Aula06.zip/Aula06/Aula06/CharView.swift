//
//  CharView.swift
//  Aula06
//
//  Created by Student02 on 19/10/23.
//

import Foundation

struct cardImage: Codable, Identifiable {
    let id: Int?
    let image_url: String?
    let image_url_small: String?
    let image_url_cropped: String?
}
struct cardscolect: Codable, Identifiable {
    let id: Int?
    let name: String?
    let type: String?
    let frameType: String?
    let desc: String?
    let race: String?
    let archetype: String?
    let card_images: cardImage?
}
