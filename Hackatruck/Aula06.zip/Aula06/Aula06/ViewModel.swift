//
//  viewModel.swift
//  apiRest
//
//  Created by Student02 on 19/10/23.
//

import Foundation

class ViewModel : ObservableObject{
    @Published var card : [cardscolect] = []
    
    func fech(){
        guard let url = URL(string: "https://db.ygoprodeck.com/api/v7/cardinfo.php"
) else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){ [weak self] data, _, error in
            guard let data = data, error == nil else{
                return
            }
            
            do {
                let parsed = try JSONDecoder().decode(cardscolect.self, from: data)
                
                DispatchQueue.main.async{
                    self?.card.append(parsed)
                }
                
            }catch{
                print(error)
            }
        }
        task.resume()
    }
}
