//
//  ContentView.swift
//  Aula06
//
//  Created by Student02 on 19/10/23.
//

import SwiftUI

struct ContentView: View {
    @StateObject var viewModel = ViewModel()
    var body: some View {
        VStack {
            Text("\(viewModel.card.count)")
             
            ForEach((1...15), id: \.self) {
                Text("\($0)…")
                //Text("\($viewModel.card.name)")
            }
        }.onAppear(){
            viewModel.fech()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
