//
//  ContentView.swift
//  Aula05
//
//  Created by Student02 on 18/10/23.
//
import MapKit
import SwiftUI

struct Location: Identifiable {
    let id = UUID()
    let name: String
    let cordinate: CLLocationCoordinate2D
    let flag: String
    let description: String
}

struct ContentView: View {
    @State private var isShowingUser = false
    @State private var txtnome: String = ""
    @State private var local = [
        Location(name: "Brasil", cordinate: CLLocationCoordinate2D(latitude:-9.797669 , longitude: -50.580709), flag: "image async", description: "brasil é legal"),
        Location(name: "Canadá", cordinate: CLLocationCoordinate2D(latitude: 56.984257, longitude: -101.763081), flag: "https://img.freepik.com/vetores-gratis/ilustracao-de-bandeira-canada_53876-27114.jpg?w=2000&t=st=1697651805~exp=1697652405~hmac=5c6953c57c93aceb300c4cd40fcc9379503c94487c284db543701b233251b7e1", description: "frio, urso e maple"),
        Location(name: "Venezuela", cordinate: CLLocationCoordinate2D(latitude: 7.544694, longitude: -66.136219), flag: "https://img.freepik.com/vetores-gratis/bandeira-de-ilustracao-da-venezuela_53876-27121.jpg?w=2000&t=st=1697651842~exp=1697652442~hmac=18b2c1a4cfdd3b395abc0512fde623e01436f8d6ea4d2b6cd255530e144d7017", description:"Petróleo, inflação e ditadura"),
        Location(name:"Austrália", cordinate: CLLocationCoordinate2D(latitude: -26.069652, longitude: 134.915455), flag:"https://img.freepik.com/vetores-gratis/ilustracao-de-australia-bandeira_53876-27116.jpg?w=2000&t=st=1697651876~exp=1697652476~hmac=db85fe5651e93195c26901b03701cc20d09037e840e95faeff6aeef0b498350e", description: "Muito bicho estranho, cuidado")]

    


    @State private var teste = MKCoordinateRegion(center: CLLocationCoordinate2D( latitude: 51.5, longitude: -0.12), span: MKCoordinateSpan(latitudeDelta: 10, longitudeDelta: 10))
    
    var body: some View {
        ScrollView{
            
            Text("World Maps")
                .font(.title)
                .bold()
            
            Text(txtnome)
            
            Map(coordinateRegion: $teste).frame(width:340,height: 500).padding()
            
            
            
            ScrollView{
                HStack{
                    ForEach(local) {
                        local in
                        Button(local.name){
                            txtnome = local.name
                            teste = MKCoordinateRegion(center: local.cordinate, span: MKCoordinateSpan(latitudeDelta: 20, longitudeDelta: 20))
                            isShowingUser = true
                            
                            
                        }.font(.caption2)
                        .foregroundColor(.white)
                            .frame(height:8)
                            .padding()
                            .background(.blue)
                            .cornerRadius(10)
                    }
                }
            }
            
        }
    }
    
}



//    .sheet(isPresented: $isShowingUser) {
//        VStack{
//            Text(local.name)
//                .font(.title)
//                .bold()
//
//            AsyncImage(url: URL(string: local.flag)!)
//
//            Text(local.description)
//        }
//    }

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
