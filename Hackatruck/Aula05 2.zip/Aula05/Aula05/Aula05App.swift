//
//  Aula05App.swift
//  Aula05
//
//  Created by Student02 on 18/10/23.
//

import SwiftUI

@main
struct Aula05App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
