//
//  FaculdadeIOSRatanabaApp.swift
//  FaculdadeIOSRatanaba
//
//  Created by Student02 on 25/10/23.
//

import SwiftUI

@main
struct FaculdadeIOSRatanabaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
