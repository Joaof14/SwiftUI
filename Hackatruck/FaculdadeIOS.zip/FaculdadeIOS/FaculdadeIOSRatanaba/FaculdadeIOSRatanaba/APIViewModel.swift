import Foundation

struct Faculdades: Decodable, Hashable{
    var NomeFaculdade: String?
    var Cidade: String?
    var ArrayPredios: [Predios]
}

struct Predios: Decodable, Hashable{
    var NomePredio: String?
    var Cursos: [Curso]
}

struct Curso: Decodable, Hashable{
    var NomeCurso: String?
    var Area: String?
}

class APIviewModel: ObservableObject {
    @Published var faculdade: [Faculdades] = []
    func fetch(){
        guard let url = URL(string: "http://127.0.0.1:1880/getFaculdade") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){[weak self] data, _, error in
            guard let data = data, error == nil else {return }
            
            do {
                let decodificado = try JSONDecoder().decode([Faculdades].self, from: data)
                
                DispatchQueue.main.async {
                    self?.faculdade = decodificado
                }
            } catch {
                print(error)
            }
                    
        }
        
        task.resume()
    }
    
}
