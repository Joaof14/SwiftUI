//
//  AssetsView.swift
//  Aula07
//
//  Created by Student02 on 20/10/23.
//

import SwiftUI

struct AssetsView: View {
    @StateObject var vm = APIviewModel()
    
    var body: some View {
        VStack{
            ZStack{
                Rectangle().fill(LinearGradient(gradient: Gradient(colors: [.blue, .white]), startPoint: .top, endPoint: .bottom)
                ).ignoresSafeArea()
                
                VStack{
                    
                    Text("Universidades Disponíveis")
                        .bold()
                        .font(.title)
                        .background(.gray)
                        .foregroundColor(.white)
                        .cornerRadius(30)
                    
                    ForEach((vm.faculdade), id: \.self){faculdade in
                        NavigationLink(destination: DetalhesAssets(nomeF: "")){
                            HStack{
                                Text(faculdade.NomeFaculdade!)
                                Spacer()
                                
                            }.padding(20)
                                .background(.gray)
                                .foregroundColor(.white)
                                .cornerRadius(30)
                        }
                    }
                }
            }
        }
            .onAppear(){
                vm.fetch()
                
        }
    }
}
                        
                               
struct AssetsView_Previews: PreviewProvider {
    static var previews: some View {
        AssetsView()
    }
}
