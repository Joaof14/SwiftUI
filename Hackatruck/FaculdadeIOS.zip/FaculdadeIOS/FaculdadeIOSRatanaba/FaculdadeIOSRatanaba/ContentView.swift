//
//  ContentView.swift
//  Aula07
//
//  Created by Student02 on 20/10/23.
//

import SwiftUI
// https:www.thingiverse.com/thing:341688
// https:www.thingiverse.com/thing:2320966
struct ContentView: View {
    var menus = ["Assets","Rates", "Exchanges", "Markets", "Candles"]
    
    var body: some View {
        NavigationStack{
            ZStack{
                
                AsyncImage(url: URL(string: "https://blog.informationplanet.com.br/wp-content/uploads/2018/12/como-fazer-faculdade-no-canada-1.jpg")){ image in
                    image
                        .resizable()
                        .scaledToFill()
                        .frame(maxWidth: 1, maxHeight: 870)
                        .ignoresSafeArea()
                        .opacity(0.8)
                    
                } placeholder: {
                    ProgressView()
                }
                
                
                
                VStack {
                
                    Spacer()
                    
                    VStack{
                        Text("Faculdade fácil").bold().foregroundColor(.white).font(.largeTitle)
                            .frame(width: 270.0, height: 70.0)
                            .background(.blue)
                            .cornerRadius(15)
                            //.opacity(0.8)
                        Text("A faculdade feita pra você!").foregroundColor(.white).font(.title3)
                            .frame(width: 180.0, height: 70.0)
                            .background(.blue)
                            .cornerRadius(15)
                            .multilineTextAlignment(.center)
                            //.opacity(0.8)
                    }
                    
                    Spacer()
                    
                    NavigationLink(destination: AssetsView()){
                        Text("Entrar").foregroundColor(.white)
                            .frame(width: 80.0, height: 50.0)
                            .background(.blue)
                            .cornerRadius(15)
                            //.opacity(0.8)
                    }
                    
                    //Spacer()
                }
                .padding()
            }
        }.accentColor(.white)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
