//
//  ContentView.swift
//  Aula04
//
//  Created by Student02 on 16/10/23.
//

import SwiftUI
import Foundation

struct Suggestion : Identifiable {
    var id: Int
    var albumCover: String
    var albumNome: String
}

struct Song : Identifiable {
    var id: Int
    var nome: String
    var artist: String
    var capa: String
}

struct ContentView: View {
    var listSong = [
        Song(id: 1, nome: "money, money, money", artist: "Anderson", capa: "https://img.freepik.com/free-vector/gradient-album-cover-template_23-2150597431.jpg?w=996&t=st=1697476513~exp=1697477113~hmac=3e7ae446d93bb03bf6fd64b09123f46fcb92b1d813053b24cb93ed54be88d267"),
        Song(id: 2, nome: "Sadness and caipirinha", artist: "João", capa: "https://img.freepik.com/free-vector/gradient-album-cover-template_23-2150597431.jpg?w=996&t=st=1697476513~exp=1697477113~hmac=3e7ae446d93bb03bf6fd64b09123f46fcb92b1d813053b24cb93ed54be88d267"),
        Song(id: 3, nome: "hard script, high money", artist: "Raimundo", capa: "https://img.freepik.com/free-vector/gradient-album-cover-template_23-2150597431.jpg?w=996&t=st=1697476513~exp=1697477113~hmac=3e7ae446d93bb03bf6fd64b09123f46fcb92b1d813053b24cb93ed54be88d267"),
        Song(id: 4, nome: "2k Tequila", artist: "Edilson", capa: "https://img.freepik.com/free-vector/gradient-album-cover-template_23-2150597431.jpg?w=996&t=st=1697476513~exp=1697477113~hmac=3e7ae446d93bb03bf6fd64b09123f46fcb92b1d813053b24cb93ed54be88d267"),
        Song(id: 5, nome: "High my life", artist: "Gabriel", capa: "https://img.freepik.com/free-vector/gradient-album-cover-template_23-2150597431.jpg?w=996&t=st=1697476513~exp=1697477113~hmac=3e7ae446d93bb03bf6fd64b09123f46fcb92b1d813053b24cb93ed54be88d267")
    ]
    var body: some View {
        NavigationStack{
            VStack{
                ZStack{
                    
                    Rectangle().fill(LinearGradient(gradient: Gradient(colors: [.blue, .black]), startPoint: .top, endPoint: .bottom)
                    ).ignoresSafeArea()
                    
                    ScrollView{
                        
                        VStack{
                            
                            Image("caminhao")
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: 300, maxHeight: 300)
                            
                            VStack {
                                HStack{
                                    Text("HackaFM")
                                        .font(.title)
                                        .bold()
                                        .foregroundColor(.white)
                                    
                                    Spacer()
                                    
                                }
                                
                                HStack{
                                    Image("caminhao")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(maxWidth: 30, maxHeight: 30)
                                    
                                    Text("HackaSong")
                                        .font(.caption)
                                        .bold()
                                        .foregroundColor(.white)
                                    
                                    Spacer()
                                }
                                
                            }.padding()
                            
                            ForEach(listSong, id: \.id) {
                                song in HStack {
                                    NavigationLink(destination : Preview(detail:song)){
                                        AsyncImage(url: URL(string: song.capa)!) { image in
                                            image
                                                .resizable()
                                                .scaledToFill()
                                                .frame(maxWidth: 50, maxHeight: 40)
                                        } placeholder: {
                                            ProgressView()
                                        }
                                        
                                        VStack(alignment: .leading){
                                            Text("\(song.nome)").foregroundColor(.white)
                                            
                                            
                                            Text("\(song.artist)").foregroundColor(.white).font(.caption)
                                            
                                        }
                                        
                                        Spacer()
                                        
                                        Image(systemName: "ellipsis").foregroundColor(.white).padding()
                                        
                                        
                                        
                                    }.padding([.top, .leading])
                                }
                            }

                            
                            HStack(alignment: .firstTextBaseline){
                                Text("Sugeridos").foregroundColor(.white).font(.title)
                                    .bold()
                                
                                Spacer()
                            }.padding()
                            
                            ScrollView(.horizontal){
                                HStack{
                                    ForEach(listSong, id: \.id) {
                                        song in HStack {
                                            NavigationLink(destination : Preview(detail:song)){
                                                
                                                VStack{
                                                    AsyncImage(url: URL(string: song.capa)!) { image in
                                                        image
                                                            .resizable()
                                                            .scaledToFill()
                                                            .frame(maxWidth: 100, maxHeight: 100)
                                                    } placeholder: {
                                                        ProgressView()
                                                    }
                                                    
                                                    Text("\(song.nome)").foregroundColor(.white)
                                                        .font(.caption)
                                                    
                                                }
                                            }.padding([.top, .leading])
                                        }
                                    }
                                }
                            }
                        }
                    } // vstack principal
                } //zstack
            }
        }.accentColor(.white)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
