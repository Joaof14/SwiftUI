//
//  Preview.swift
//  Aula04
//
//  Created by Student02 on 16/10/23.
//

import SwiftUI

struct Preview: View {
    @State public var detail: Song
    
    var body: some View {
        ZStack {
            
            Rectangle().fill(LinearGradient(gradient: Gradient(colors: [.blue, .black]), startPoint: .top, endPoint: .bottom)
            ).ignoresSafeArea()
            
            VStack{
                
                AsyncImage(url: URL(string: detail.capa)!) { image in
                    image
                        .resizable()
                        .scaledToFill()
                        .frame(maxWidth: 100, maxHeight: 100)
                } placeholder: {
                    ProgressView()
                }
                
                Text("\(detail.nome)").foregroundColor(.white)
                    
                
                Text("\(detail.artist)").foregroundColor(.white).font(.caption)
                
                HStack{
                    
                    Image(systemName: "shuffle").foregroundColor(.white)
                        .font(.system(size: 25))
                        .padding()

                    Image(systemName: "backward.end.fill").foregroundColor(.white)
                        .font(.system(size: 25))
                        .padding()

                    Image(systemName: "play.fill")
                        .foregroundColor(.white)
                        .font(.system(size: 40))
                        .padding()
                    
                    Image(systemName: "forward.end.fill").foregroundColor(.white)
                        .font(.system(size: 25))
                        .padding()

                    Image(systemName: "repeat").foregroundColor(.white)
                        .font(.system(size: 25))
                        .padding()

                }.padding()
            }
        }
    }
}

struct Preview_Previews: PreviewProvider {
    static var previews: some View {
        Preview(detail: Song(id:0, nome:"", artist:"", capa:"test"))
    }
}
