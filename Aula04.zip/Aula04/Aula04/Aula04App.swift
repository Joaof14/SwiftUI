//
//  Aula04App.swift
//  Aula04
//
//  Created by Student02 on 16/10/23.
//

import SwiftUI

@main
struct Aula04App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
