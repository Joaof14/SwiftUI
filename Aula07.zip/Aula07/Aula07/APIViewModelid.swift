//
//  APIViewModelid.swift
//  Aula07
//
//  Created by Student02 on 20/10/23.
//

import Foundation
struct APIInfo: Decodable {
    var data: CoinId
}

struct CoinId: Decodable, Identifiable{
    var id: String?
    var rank: String?
    var symbol: String?
    var name: String?
    var supply: String?
    var maxSupply: String?
    var marketCapUsd: String?
    var priceUsd: String?
    var explorer: String?
}

class APIviewModelid: ObservableObject {
    @Published var coinId: [CoinId] = []
    
    func fetchId(Id: String){
        guard let url = URL(string: "https://api.coincap.io/v2/assets/\(Id)") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url){[weak self] data, _, error in
            guard let data = data, error == nil else {return }
            
            do {
                let decodificado = try JSONDecoder().decode(APIInfo.self, from: data)
                
                DispatchQueue.main.async {
                    self?.coinId.append(decodificado.data)
                }
            } catch {
                print(error)
            }
                    
        }
        
        task.resume()
    }
}

