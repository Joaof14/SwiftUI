//
//  DetalhesAssets.swift
//  Aula07
//
//  Created by Student02 on 20/10/23.
//

import SwiftUI

struct DetalhesAssets: View {
    @StateObject var vmm = APIviewModelid()
    var coinId: String
    
    var body: some View {
        VStack{
            //Text(coinId)
            ForEach(vmm.coinId) { index in
                Text("Nome: \( index.name!)")
                Text("Demanda: \(index.supply!)")
                
            }
                
        }.onAppear(){vmm.fetchId(Id: coinId)}
    }
}

struct DetalhesAssets_Previews: PreviewProvider {
    static var previews: some View {
        DetalhesAssets(coinId: "Bitcoin")
    }
}
