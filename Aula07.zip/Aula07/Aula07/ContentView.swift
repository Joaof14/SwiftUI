//
//  ContentView.swift
//  Aula07
//
//  Created by Student02 on 20/10/23.
//

import SwiftUI
// https:www.thingiverse.com/thing:341688
// https:www.thingiverse.com/thing:2320966
struct ContentView: View {
    var menus = ["Assets","Rates", "Exchanges", "Markets", "Candles"]
    
    var body: some View {
        NavigationStack{
            VStack {
                NavigationLink(destination: AssetsView()){
                    Text("Assets")
                }
            }
            .padding()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
