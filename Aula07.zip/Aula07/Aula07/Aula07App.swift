//
//  Aula07App.swift
//  Aula07
//
//  Created by Student02 on 20/10/23.
//

import SwiftUI

@main
struct Aula07App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
